TransferHub · Offline receiver
===============================
1. Plug the TransferHub into the computer USB port.
2. Open TransferHub-Receiver.html in Chrome or Microsoft Edge.
3. Select the USB device, log in with your device password, and choose a destination folder.
4. On the phone, join the transferhub Wi-Fi and open http://192.168.77.1/send.

No localhost service, account, or internet connection is required for the receiver HTML.
Use the settings button to change transfer mode or device login password if your firmware supports it.
The device login password is distinct from the Wi-Fi password.
